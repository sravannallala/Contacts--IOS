//
//  networkCallingViewController.swift
//  contacts
//
//  Created by sravan nallala on 12/01/20.
//  Copyright © 2020 SRAVAN NALLALA . All rights reserved.
//

import UIKit
import Alamofire


class networking {
    typealias webResponse = ([[String:Any]]? , Error?) -> Void
    
    
   
  
    func executeGet(_ url: URL , completion: @escaping webResponse ) {
        Alamofire.request(url, method: .get).responseJSON { response in
            
            if let error = response.error {
                completion(nil, error)
            } else if let jsonArray = response.result.value as? [[String:Any]] {
                completion(jsonArray , nil)
            } else if let jsonDict = response.result.value as? [String:Any] {
                completion([jsonDict] , nil)
                
            }
            
        }
        
    }
    
    
    
}

