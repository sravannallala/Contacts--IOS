//
//  ViewController.swift
//  contacts
//
//  Created by sravan nallala on 12/01/20.
//  Copyright © 2020 SRAVAN NALLALA All rights reserved.
//

import UIKit
import Alamofire
import SDWebImage




let network = networking()
let mainColor = UIColor(red: 194/255, green: 194/255, blue: 194/255, alpha: 0.4)
class ViewController: UIViewController , UITableViewDelegate , UITableViewDataSource {
   
    

    
    @IBOutlet weak var contactTableView: UITableView!
    
    var HomeDict = [[String:Any]]()
    
    
    override func viewWillAppear(_ animated: Bool) {
        
//         self.navigationController?.navigationBar.prefersLargeTitles = true
        self.navigationItem.title = "Contacts"
       
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
        
        contactTableView.tableFooterView = UIView()
        apiCalling()
    }


    func apiCalling() {
        
       
              self.contactTableView.isHidden = true
      
            let uurl =   "https://randomuser.me/api/?results=50"
        
            
            guard let urlexecute = URL(string: uurl) else {
                return
            }
            
            network.executeGet(urlexecute) { (json, error) in
                if let error = error {
                    print(error)
                } else if let json = json {
                    
                     self.HomeDict = json[0]["results"] as! [[String : Any]]
                   
                }
                
                DispatchQueue.main.async {
                    
                     self.contactTableView.isHidden = false
                    self.contactTableView.reloadData()
                  
                }
                
            }
            
        }
    
    
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return HomeDict.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         let cell = tableView.dequeueReusableCell(withIdentifier: "tableCell") as! contactCustomCellTableViewCell
        
        
         let individual = HomeDict[indexPath.row]
        
        
        if indexPath.row % 2 == 0 {
            cell.backgroundColor = mainColor
        } else {
            cell.backgroundColor = UIColor.white
        }
    
        let fullname = individual["name"] as! [String:String]
        cell.nameLbl?.text = fullname["first"]! + " " + fullname["last"]!
        cell.emailLbl?.text = individual["email"] as? String
        
        
        let image = individual["picture"] as! [String:String]
        let url = image["thumbnail"]!
        
        cell.mainImgView.sd_setImage(with: URL(string: url), placeholderImage: nil)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "detailViewController") as! detailViewController
         let individual = HomeDict[indexPath.row]
        vc.detailContact = individual
        
       self.navigationController?.pushViewController(vc, animated: true)
    }
    

}

