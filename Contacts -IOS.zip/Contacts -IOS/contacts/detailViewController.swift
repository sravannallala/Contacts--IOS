//
//  detailViewController.swift
//  contacts
//
//  Created by sravan nallala on 12/01/20.
//  Copyright © 2020 SRAVAN NALLALA . All rights reserved.
//

import UIKit

class detailViewController: UIViewController {

    
    var detailContact = [String:Any]()
    
    
    
    @IBOutlet weak var mainImg: UIImageView!
    
    
    @IBOutlet weak var nameLbl: UILabel!
    
    @IBOutlet weak var phoneLbl: UILabel!
    
    @IBOutlet weak var cellLbl: UILabel!
    
    
    @IBOutlet weak var emailLbl: UILabel!
    
    @IBOutlet weak var addressLbl: UILabel!
    
    
    
    override func viewWillAppear(_ animated: Bool) {
         self.navigationController?.navigationBar.prefersLargeTitles = false
    }
    override func viewDidLoad() {
        super.viewDidLoad()
       
        imageCrop()
        let image = detailContact["picture"] as! [String:String]
        let url = image["medium"]!
        self.mainImg.sd_setImage(with: URL(string: url), placeholderImage: nil)
        
        let fullname = detailContact["name"] as! [String:String]
        self.nameLbl.text = "Name  : " +  fullname["title"]! + " " + fullname["first"]! + " " + fullname["last"]!
        
        self.phoneLbl.text = "Phone : " + (detailContact["phone"] as? String ?? " ")
        
        self.cellLbl.text = "Cell      : " + (detailContact["cell"] as? String ?? " ")
        
        self.emailLbl.text =  "Email   : " + (detailContact["email"] as? String ?? " ")
        
        
         let city =  detailContact["location"] as! [String:Any]
       
        let street =  detailContact["street"] as? String ?? " "
        
        if street == " " {
            
            let address = "Address : " + (city["city"] as? String ?? " ")
            
            self.addressLbl.text = address
        } else {
        let address = "Address : " + street  + ", " + (city["city"] as! String)

        self.addressLbl.text = address
        }
       

        // Do any additional setup after loading the view.
    }
    
    
    func imageCrop() {
        mainImg.layer.borderWidth=1.0
        mainImg.layer.masksToBounds = false
        mainImg.layer.borderColor = UIColor.white.cgColor
        mainImg.layer.cornerRadius = mainImg.frame.size.height/2
        mainImg.clipsToBounds = true
    }

    
    override func viewWillDisappear(_ animated: Bool) {
         self.navigationController?.navigationBar.prefersLargeTitles = true
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
